/*
 ============================================================================
 Name        : COGL.c
 Author      : Karan Kaushal
 Version     :
 Copyright   : Your copyright notice
 Description : Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include<stdio.h>

int row_size, col_size, as, row_alive, col_alive, generations;

void NextMove(int a[row_size][col_size], int row_size, int col_size);

int main()
{

	printf("Enter the size of row\n");
	scanf("%d", &row_size);
	printf("Enter the size of column\n");
	scanf("%d", &col_size);


	int a[row_size][col_size];

	for(int p = 0; p<row_size; p++){
		for(int q = 0; q<col_size; q++){
			a[p][q] = 0;
		}
	}

	printf("Enter the number of alive cells\n");
	scanf("%d", &as);

	for(int o = 0; o<as; o++){
		printf("Enter the row of alive cell\n");
		scanf("%d", &row_alive);
		printf("Enter the column of alive cell\n");
		scanf("%d", &col_alive);
		a[row_alive][col_alive] = 1;

	}

	printf("Initial State\n");
	for (int i = 0; i < row_size; i++)
	{
		for (int j = 0; j < col_size; j++)
		{
			if (a[i][j] == 0)
				printf("0");
			else
				printf("1");
		}
		printf("\n");
	}
	printf("\n");
	NextMove(a, row_size, col_size);
}


void NextMove(int a[row_size][col_size], int row_size, int col_size)

{

	int no = 1;
	int b[row_size][col_size];

	printf("Enter the number of generations\n");
	scanf("%d", &generations);
	printf("\n");

	for(int g = 0; g<generations; g++){
		for (int l = 1; l < row_size ; l++)
		{
			for (int m = 1; m < col_size ; m++)
			{

				int numOfAliveNeighbours = 0;


				if(l == 0){
					for (int i = 0; i <= 1; i++)
						for (int j = -1; j <= 1; j++)
							numOfAliveNeighbours += a[l + i][m + j];

					numOfAliveNeighbours -= a[l][m];
				}


				else if(l == 0 && m == 0){
					for (int i = 0; i <= 1; i++)
						for (int j = 0; j <= 1; j++)
							numOfAliveNeighbours += a[l + i][m + j];

					numOfAliveNeighbours -= a[l][m];

				}


				else if(m == 0){
					for (int i = -1; i <= 1; i++)
						for (int j = 0; j <= 1; j++)
							numOfAliveNeighbours += a[l + i][m + j];

					numOfAliveNeighbours -= a[l][m];

				}


				else if(m == 0 && l == row_size - 1){
					for (int i = -1; i < 1; i++)
						for (int j = 0; j <= 1; j++)
							numOfAliveNeighbours += a[l + i][m + j];

					numOfAliveNeighbours -= a[l][m];

				}

				else if(l == row_size - 1){
					for (int i = -1; i < 1; i++)
						for (int j = -1; j <= 1; j++)
							numOfAliveNeighbours += a[l + i][m + j];

					numOfAliveNeighbours -= a[l][m];

				}

				else if(l == row_size -1 && m == col_size -1){
					for (int i = -1; i < 1; i++)
						for (int j = -1; j < 1; j++)
							numOfAliveNeighbours += a[l + i][m + j];

					numOfAliveNeighbours -= a[l][m];

				}

				else if(m == col_size -1 ){
					for (int i = -1; i <= 1; i++)
						for (int j = -1; j < 1; j++)
							numOfAliveNeighbours += a[l + i][m + j];

					numOfAliveNeighbours -= a[l][m];

				}

				else if(l == 0 && m == col_size - 1){
					for (int i = 0; i <= 1; i++)
						for (int j = -1; j < 1; j++)
							numOfAliveNeighbours += a[l + i][m + j];

					numOfAliveNeighbours -= a[l][m];

				}

				else {
					for (int i = -1; i <= 1; i++)
						for (int j = -1; j <= 1; j++)
							numOfAliveNeighbours += a[l + i][m + j];

					numOfAliveNeighbours -= a[l][m];

				}


				if ((a[l][m] == 1) && (numOfAliveNeighbours < 2))
					b[l][m] = 0;


				else if ((a[l][m] == 1) && (numOfAliveNeighbours > 3))
					b[l][m] = 0;


				else if ((a[l][m] == 0) && (numOfAliveNeighbours == 3))
					b[l][m] = 1;


				else
					b[l][m] = a[l][m];
			}
		}


		printf("%d Generation:\n", no);
		no++;
		for (int i = 0; i < row_size; i++)
		{
			for (int j = 0; j < col_size; j++)
			{
				if (a[i][j] == 0)
					printf("0");
				else
					printf("1");
			}
			printf("\n");
		}
		printf("\n");
	}
}


